package astanait.edu.kz;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "Servlet1")
public class Servlet1 extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String login = request.getParameter("login");

        String password = request.getParameter("password");

        String log = "astanait";
        String pass = "2020";

        if (login.equals(log) && password.equals(pass)) {
            Cookie cookie = new Cookie("usernameCookie",login);
            cookie.setMaxAge(60*5);
            response.addCookie(cookie);
            User user1 = addUser(request  , response);
            request.setAttribute("user", user1);
            request.getRequestDispatcher("page-2.jsp").forward(request,response);
        }
        else {
            request.getRequestDispatcher("errorPage.jsp").forward(request,response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
    private User addUser(HttpServletRequest request , HttpServletResponse response) {

        User user = new User();
        user.setLogin(request.getParameter("login"));
        user.setPassword(request.getParameter("password"));
        return user;
    }
}
